function a() {
console.log("Text");
}